﻿namespace LMKit.Maestro.ViewModels;

public enum MessageSender
{
    Undefined,
    User,
    Assistant
}
