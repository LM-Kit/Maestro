﻿namespace LMKit.Maestro.ViewModels
{
    public enum DownloadStatus
    {
        NotDownloaded,
        Downloaded,
        Downloading,
        DownloadPaused,
    }
}
