﻿namespace LMKit.Maestro.Services;

public enum SamplingMode
{
    Greedy,
    Random,
    TopNSigma,
    Mirostat2
}
