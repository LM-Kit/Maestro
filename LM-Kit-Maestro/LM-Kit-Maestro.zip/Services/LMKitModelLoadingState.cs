﻿namespace LMKit.Maestro.Services;

public enum LMKitModelLoadingState
{
    Unloaded,
    Loading,
    Loaded
}
