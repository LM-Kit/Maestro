﻿namespace LMKit.Maestro.Services;

public enum LMKitRequestStatus
{
    OK,
    Cancelled,
    GenericError
}